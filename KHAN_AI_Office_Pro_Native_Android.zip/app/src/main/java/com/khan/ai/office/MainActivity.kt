package com.khan.ai.office

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper

private val tasks = listOf(
    "Letter Drafting","GR Analysis","Note Sheet","WhatsApp Message",
    "Press Note","Meeting Proceedings","Resolution Draft",
    "Inspection Report","Excel Analysis"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent { KhanApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KhanApp(context: Context) {
    val prefs = context.getSharedPreferences("khan", Context.MODE_PRIVATE)
    var apiKey by remember { mutableStateOf(prefs.getString("api_key","") ?: "") }
    var language by remember { mutableStateOf("Marathi") }
    var task by remember { mutableStateOf(tasks.first()) }
    var details by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var fileText by remember { mutableStateOf("") }
    var fileName by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            try {
                fileName = uri.lastPathSegment ?: "selected file"
                fileText = if (task == "GR Analysis") extractPdf(context, uri) else extractXlsx(context, uri)
            } catch (e: Exception) {
                fileText = "File reading error: ${e.message}"
            } finally { busy = false }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🏛️ KHAN AI Office Pro") },
                actions = { TextButton(onClick = { showSettings = true }) { Text("⚙") } }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("Government Office Smart Assistant", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))

            ExposedDropdownMenuBox(expanded = menuOpen, onExpandedChange = { menuOpen = !menuOpen }) {
                OutlinedTextField(
                    value = language, onValueChange = {}, readOnly = true,
                    label = { Text("Language") }, modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    listOf("Marathi","English").forEach {
                        DropdownMenuItem(text = { Text(it) }, onClick = { language = it; menuOpen = false })
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            TaskDropdown(task, { task = it })

            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = details, onValueChange = { details = it },
                label = { Text("Enter Details") }, minLines = 5,
                modifier = Modifier.fillMaxWidth()
            )

            if (task == "GR Analysis" || task == "Excel Analysis") {
                Spacer(Modifier.height(10.dp))
                Button(onClick = {
                    picker.launch(arrayOf(
                        if (task == "GR Analysis") "application/pdf"
                        else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    ))
                }) { Text(if (task == "GR Analysis") "📄 Upload GR PDF" else "📊 Upload Excel") }
                if (fileName.isNotBlank()) Text("Selected: $fileName")
            }

            Spacer(Modifier.height(14.dp))
            Button(
                enabled = !busy && apiKey.isNotBlank(),
                onClick = {
                    scope.launch {
                        busy = true
                        output = try {
                            Gemini.generate(apiKey, language, task, details, fileText)
                        } catch (e: Exception) {
                            "Error: ${e.message}"
                        } finally { busy = false }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "Generating..." else "Generate") }

            if (apiKey.isBlank()) {
                Text("पहले ⚙ Settings में Gemini API key डालें।", color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))
            if (output.isNotBlank()) {
                Text("Generated Output", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = output, onValueChange = { output = it },
                    minLines = 12, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Button(onClick = { savePdf(context, output) }, modifier = Modifier.fillMaxWidth()) {
                    Text("📄 Download PDF")
                }
            }
        }
    }

    if (showSettings) {
        var temp by remember { mutableStateOf(apiKey) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Settings") },
            text = {
                OutlinedTextField(
                    value = temp, onValueChange = { temp = it },
                    label = { Text("Gemini API Key") }, singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    apiKey = temp.trim()
                    prefs.edit().putString("api_key", apiKey).apply()
                    showSettings = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun TaskDropdown(value: String, onChange: (String)->Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(value = value, onValueChange = {}, readOnly = true,
            label = { Text("Select Task") }, modifier = Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            tasks.forEach { t -> DropdownMenuItem(text = { Text(t) }, onClick = { onChange(t); expanded = false }) }
        }
    }
}

object Gemini {
    private val client = OkHttpClient()
    fun generate(key: String, language: String, task: String, user: String, attachment: String): String {
        val prompt = """
You are KHAN AI Office Pro.

Task Type: $task
Language: $language

Rules:
- If Language is Marathi, generate output in official Maharashtra Government Marathi.
- If Language is English, generate professional official English.
- Follow Maharashtra Government drafting style.
- Generate complete output.
- For Letter Drafting include Subject, Reference and Main Letter.
- For Note Sheet generate official note format.
- For Press Note generate media-ready content.
- For Resolution Draft generate Gram Panchayat resolution.
- For WhatsApp Message generate short official message.
- For Excel Analysis provide summary, key findings, totals, trends and recommendations.
- For GR Analysis provide Summary, Important Instructions, Action Points, BDO Responsibility and Gram Panchayat Responsibility.

User Request:
$user

Uploaded File Content:
$attachment
""".trimIndent()

        val body = JSONObject()
            .put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            )).toString()

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(req).execute().use { response ->
            val raw = response.body?.string() ?: ""
            if (!response.isSuccessful) error("Gemini API ${response.code}: $raw")
            val json = JSONObject(raw)
            return json.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text")
        }
    }
}

suspend fun extractPdf(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
    context.contentResolver.openInputStream(uri).use { input ->
        val doc = PDDocument.load(input)
        doc.use { PDFTextStripper().getText(it).take(15000) }
    }
}

suspend fun extractXlsx(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
    val entries = mutableMapOf<String, ByteArray>()
    context.contentResolver.openInputStream(uri).use { input ->
        ZipInputStream(input).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (!e.isDirectory) {
                    val out = ByteArrayOutputStream()
                    zip.copyTo(out)
                    entries[e.name] = out.toByteArray()
                }
            }
        }
    }
    val shared = entries["xl/sharedStrings.xml"]?.toString(Charsets.UTF_8) ?: ""
    val sheet = entries["xl/worksheets/sheet1.xml"]?.toString(Charsets.UTF_8) ?: ""
    val strings = Regex("<t[^>]*>(.*?)</t>").findAll(shared)
        .map { it.groupValues[1].replace("&amp;","&").replace("&lt;","<").replace("&gt;",">") }
        .toList()
    val cells = Regex("<c([^>]*)>(.*?)</c>").findAll(sheet).map { it.groupValues[1] to it.groupValues[2] }
    val sb = StringBuilder()
    for ((attrs, body) in cells) {
        val ref = Regex("""r="([^"]+)"""").find(attrs)?.groupValues?.get(1) ?: ""
        val type = Regex("""t="([^"]+)"""").find(attrs)?.groupValues?.get(1)
        val v = Regex("<v>(.*?)</v>").find(body)?.groupValues?.get(1) ?: ""
        val value = if (type == "s") strings.getOrNull(v.toIntOrNull() ?: -1) ?: v else v
        if (ref.isNotBlank()) sb.append(ref).append("=").append(value).append(" | ")
        if (sb.length > 12000) break
    }
    sb.toString()
}

fun savePdf(context: Context, text: String) {
    val doc = PdfDocument()
    val page = doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create())
    val canvas = page.canvas
    val paint = Paint().apply { textSize = 12f }
    var y = 40f
    val maxWidth = 540f
    val words = text.replace("\r","").split(" ")
    var line = ""
    for (word in words) {
        val candidate = if (line.isEmpty()) word else "$line $word"
        if (paint.measureText(candidate) > maxWidth) {
            canvas.drawText(line, 25f, y, paint); y += 18f; line = word
            if (y > 810f) break
        } else line = candidate
    }
    if (line.isNotEmpty() && y <= 810f) canvas.drawText(line,25f,y,paint)
    doc.finishPage(page)
    val file = java.io.File(context.getExternalFilesDir(null), "KHAN_AI_Output.pdf")
    file.outputStream().use { doc.writeTo(it) }
    doc.close()
}
