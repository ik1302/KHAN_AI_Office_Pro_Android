# KHAN AI Office Pro — Native Android APK

This is a **native Kotlin + Jetpack Compose** Android app. It does **not** use WebView.

## Current features
- Marathi / English
- 9 office tasks matching the Streamlit version
- Native PDF picker and PDF text extraction
- Basic XLSX extraction for first worksheet data
- Gemini 2.5 Flash generation
- Native PDF output
- GitHub Actions debug APK build

## Important security note
The Gemini key is entered by the user in Settings and stored locally. For a production government deployment, a secure backend/proxy is recommended instead of distributing a reusable API key in an APK.

## Build from GitHub
Upload the `android/` folder and `.github/workflows/build-apk.yml` to your repository. Then:
GitHub → Actions → Build KHAN AI Office APK → Run workflow.
The APK will appear under Artifacts.
